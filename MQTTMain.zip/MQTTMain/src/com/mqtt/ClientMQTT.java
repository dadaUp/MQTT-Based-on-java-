package com.mqtt;

import java.util.concurrent.ScheduledExecutorService;  
import org.eclipse.paho.client.mqttv3.MqttClient;  
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;  
import org.eclipse.paho.client.mqttv3.MqttException;  
import org.eclipse.paho.client.mqttv3.MqttTopic;  
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;  
 
/**
 * 模拟一个客户端接收消息
 * Simulate a client to receive messages
 * @author dadaUp
 * https://github.com/dadaUp/MQTT-Based-on-java-
 */
public class ClientMQTT {  
  
    public static final String HOST = "tcp://sichang.com.cn:1883";  
    public static final String TOPIC1 = "posMessage";  
    private static final String clientid = "client11";  
    private MqttClient client;  
    private MqttConnectOptions options;  
    private String userName = "admin";  
    private String passWord = "password";  
    @SuppressWarnings("unused")
	private ScheduledExecutorService scheduler;  
  
    private void start() {  
        try {  
            //host为主机名，clientid即连接MQTT的客户端ID，一般以唯一标识符表示，MemoryPersistence设置clientid的保存形式，默认为以内存保存  
        	//host for the host name, clientid that is connected to the MQTT client ID, generally a unique identifier,MemoryPersistence set clientid saved form, the default is to save memory
            client = new MqttClient(HOST, clientid, new MemoryPersistence());  
           
            //MQTT的连接设置  
            //MQTT connection settings
            options = new MqttConnectOptions();  
           
            //设置是否清空session,这里如果设置为false表示服务器会保留客户端的连接记录，设置为true表示每次连接到服务器都以新的身份连接  
            //Set whether to clear the session, if set to false here that the server will retain the client's connection record, set to true that each time the connection to the server are connected in a new identity  
            options.setCleanSession(false);  
           
            //设置连接的用户名  
            //Set the user name of the connection  
            options.setUserName(userName);  
            
            //设置连接的密码  
            //Set the password for the connection  
            options.setPassword(passWord.toCharArray());  
           
            //设置超时时间 单位为秒  
            //Set the timeout in seconds 
            options.setConnectionTimeout(10);  
          
            //设置会话心跳时间 单位为秒 服务器会每隔1.5*20秒的时间向客户端发送个消息判断客户端是否在线，但这个方法并没有重连的机制  
            //Set the session heartbeat time unit for the second server every 1.5 * 20 seconds to send a message to the client to determine whether the client online, but this method does not re-connect the mechanism  
            options.setKeepAliveInterval(20);  
           
            //设置回调  
            //Set the callback  
            client.setCallback(new PushCallback());  
            MqttTopic topic = client.getTopic(TOPIC1);  
          
            //setWill方法(遗嘱)，如果项目中需要知道客户端是否掉线可以调用该方法。设置最终端口的通知消息 
            //setWill method (testament), if the project needs to know whether the client is dropped or can call the method. Set the notification message for the final port 
            options.setWill(topic, "close".getBytes(), 2, true);  
           
            client.connect(options);  
          
            //订阅消息  
            //Subscribe to the message 
            int[] Qos  = {1};  
            String[] topic1 = {TOPIC1};  
            client.subscribe(topic1, Qos);  
  
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
    }  
  
    //启动入口
    //main function
    public static void main(String[] args) throws MqttException {  
        ClientMQTT client = new ClientMQTT();  
        client.start();  
    }  
}  