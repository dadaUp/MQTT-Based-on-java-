package com.mqtt;

import org.eclipse.paho.client.mqttv3.MqttClient;  
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;  
import org.eclipse.paho.client.mqttv3.MqttDeliveryToken;  
import org.eclipse.paho.client.mqttv3.MqttException;  
import org.eclipse.paho.client.mqttv3.MqttMessage;  
import org.eclipse.paho.client.mqttv3.MqttPersistenceException;  
import org.eclipse.paho.client.mqttv3.MqttTopic;  
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;  
/** 
 * 这是发送消息的服务端</br>
 * 服务器向多个客户端推送主题,即不同客户端可向服务器订阅相同主题 
 * This is the server that sends the message, </br>
 * and the server pushes the theme to multiple clients, that is, different clients can subscribe to the same topic
 * @author dadaUp 
 * https://github.com/dadaUp/MQTT-Based-on-java-
 */  
public class ServerMQTT {  
  
    //tcp://MQTT安装的服务器地址:MQTT定义的端口号  
	//tcp: // MQTT installed server address: MQTT defined port number
    public static final String HOST = "tcp://dev.sichang.com.cn:1883";  
   
    //定义一个主题  
    //Define a theme 
    public static final String TOPIC = "pos_message_all";  
   
    //定义MQTT的ID，可以在MQTT服务配置中指定  
    //The ID of the MQTT can be specified in the MQTT service configuration
    private static final String clientid = "server11";  
  
    private MqttClient client;  
    private MqttTopic topic11;  
    private String userName = "paho";  
    private String passWord = "******";  
  
    private MqttMessage message;  
  
    /** 
     * 构造函数 
     * Constructor 
     * @throws MqttException 
     */  
    public ServerMQTT() throws MqttException {  
        // MemoryPersistence设置clientid的保存形式，默认为以内存保存  
    	// MemoryPersistence set clientid saved form, the default is to save memory
    	client = new MqttClient(HOST, clientid, new MemoryPersistence());  
        connect();  
    }  
  
    /** 
     *  用来连接服务器 
     *  Used to connect to the server
     */  
    private void connect() {  
        MqttConnectOptions options = new MqttConnectOptions();  
        options.setCleanSession(false);  
        options.setUserName(userName);  
        options.setPassword(passWord.toCharArray());  
        // 设置超时时间  
        // Set the timeout time  
        options.setConnectionTimeout(10);  
        // 设置会话心跳时间  
        // Set the session heartbeat time  
        options.setKeepAliveInterval(20);  
        try {  
            client.setCallback(new PushCallback());  
            client.connect(options);  
  
            topic11 = client.getTopic(TOPIC);  
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
    }  
  
    /** 
     * 给所有订阅该主题的客户端推送消息
     * Push messages to all clients subscribing to this topic
     * @param topic 主题
     * @param message 消息
     * @throws MqttPersistenceException 
     * @throws MqttException 
     */  
    public void publish(MqttTopic topic , MqttMessage message) throws MqttPersistenceException,  
            MqttException {  
        MqttDeliveryToken token = topic.publish(message);  
        token.waitForCompletion();  
        System.out.println("message is published completely! "  
                + token.isComplete());  
    }  
  
    /** 
     *  启动入口
     *  main function
     * @param args 
     * @throws MqttException 
     */  
    public static void main(String[] args) throws MqttException {  
        ServerMQTT server = new ServerMQTT();  
  
        server.message = new MqttMessage();  
        server.message.setQos(1);  
        server.message.setRetained(true);  
        server.message.setPayload("这是推送消息的内容（This is the content of the push message）".getBytes());  
        server.publish(server.topic11 , server.message);  
        System.out.println(server.message.isRetained() + "------ratained状态");  
    }  
}  
