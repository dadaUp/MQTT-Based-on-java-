package com.mqtt.action;

import org.eclipse.paho.client.mqttv3.MqttMessage;
import com.mqtt.util.ServerMQTTUtil;
import java.util.Arrays;
import java.util.List;

public class MessageAction {
	// 接收的字段
	private String deviceIdList; //设备id列表(逗号分隔),all即为全量发送
	// 返回的字段
	private int retCode;
	private String retMsg;
	// 发送消息action
	public String sendMessage() {
		try {
		//将信息写入消息体
		MqttMessage mqttMessage = new MqttMessage();
		String MQTTObject = "***************";
		mqttMessage.setQos(1);
		mqttMessage.setRetained(true);
		mqttMessage.setPayload(MQTTObject.getBytes("UTF-8"));
		
		//根据deviceIdList内容进行topic设置和发送推送
		if (!deviceIdList.equals("all")) {
			List<String> deviceList = Arrays.asList(deviceIdList.split(","));
			for (int i =0; i < deviceList.size(); i++) {
			
			String topic = "posMessage_" + deviceList.get(i);
			ServerMQTTUtil serverMQTTUtil = new ServerMQTTUtil(topic);
			serverMQTTUtil.publish(mqttMessage);
			System.out.println(mqttMessage.isRetained() + "------ratained状态");
			}
		} else {
			String topic = "posMessageAll";
			ServerMQTTUtil serverMQTTUtil = new ServerMQTTUtil(topic);
			serverMQTTUtil.publish(mqttMessage);
			System.out.println(mqttMessage.isRetained() + "------ratained状态");
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
	return "sendMessage" ;	
	}
	
	public void setDeviceIdList(String deviceIdList) {
		this.deviceIdList = deviceIdList;
	}
	public int getRetCode() {
		return retCode;
	}
	public String getRetMsg() {
		return retMsg;
	}
}


